# To Do List Site
## Dylan Haugee
### Usage:
Using info in data.js, connect to database on cse lab machine. Enter "node server.js" in terminal to run site. 
### Advanced Feature:
Deadlines